function saisie(txt_defaut,nom_controle)
{
if(document.getElementById(nom_controle).value==txt_defaut)
document.getElementById(nom_controle).value='' ;
if(nom_controle=='tel'){
  if(document.getElementById('cont').value=='Maroc'){
    document.getElementById('tel').value='';
    document.getElementById('tel').value='+212';
  }else if(document.getElementById('cont').value=='Allemagne'){
    document.getElementById('tel').value='';
    document.getElementById('tel').value='+49';
  }else if(document.getElementById('cont').value=='États-Unis'){
    document.getElementById('tel').value='';
    document.getElementById('tel').value='+1';
  }else if(document.getElementById('cont').value=='Égypte'){
    document.getElementById('tel').value='';
    document.getElementById('tel').value='+20';
  }else if(document.getElementById('cont').value=='choisir votre pays :'){
    document.getElementById('tel').value='';
  } 
}
}

function retablir(txt_defaut,nom_controle)
{
 if( document.getElementById(nom_controle).value=='')
  document.getElementById(nom_controle).value=txt_defaut ;
}

function mev(txt_defaut,nom_controle)
{
  var longueur = document.getElementById(nom_controle).value.length;

 if(nom_controle=='mail_inscr')
{
if(document.getElementById(nom_controle).value.indexOf('@') == -1 || document.getElementById(nom_controle).value.indexOf('.') == -1)
{
document.getElementById(nom_controle).style.border = '#CC3300 2px solid';
document.getElementById('message').innerText = 'Votre mail ne semble pas correct, corrigez-le';
b_mail=false;
}
else if(document.getElementById('cmail_inscr').value != '' && document.getElementById('cmail_inscr').value != 'Confirmerle mail')
{
if(document.getElementById(nom_controle).value != document.getElementById('cmail_inscr').value)
{
document.getElementById(nom_controle).style.border = '#CC3300 2px solid';
document.getElementById('message').innerText = 'Les deux mails ne correspondent pas';
b_mail=false;
}else
{
document.getElementById('message').innerText = '';
document.getElementById(nom_controle).style.border = '#333 1px solid';
}
}
}
else if(nom_controle=='cmail_inscr')
{
if(document.getElementById(nom_controle).value.indexOf('@') == -1 || document.getElementById(nom_controle).value.indexOf('.') == -1)
{
document.getElementById(nom_controle).style.border = '#CC3300 2px solid';
document.getElementById('message').innerText = 'Votre confirmation de mail ne semble pas correcte, corrigez-le';
b_mail=false;
}
else if(document.getElementById(nom_controle).value != document.getElementById('mail_inscr').value)
{
document.getElementById(nom_controle).style.border = '#CC3300 2px solid';
document.getElementById('message').innerText = 'Les deux mails ne correspondent pas';
b_mail=false;
}
else
{
document.getElementById('message').innerText = '';
document.getElementById(nom_controle).style.border = '#333 1px solid';
b_mail=true;
}
}
else if(nom_controle=='mp_inscr')
{
if(document.getElementById(nom_controle).value.length < 5 || document.getElementById(nom_controle).value.length > 10)
{
document.getElementById(nom_controle).style.border = '#CC3300 2px solid';
document.getElementById('message').innerText = 'Le mot de passe doit comporter entre 5 et 10 caractères';
b_mp=false;
}
else
{
document.getElementById('message').innerText = '';
document.getElementById(nom_controle).style.border = '#333 1px solid';
}
}
else if(nom_controle=='mp_conf')
{
if(document.getElementById(nom_controle).value != document.getElementById('mp_inscr').value)
{
document.getElementById(nom_controle).style.border = '#CC3300 2px solid';
document.getElementById('message').innerText = 'Les mots de passe doivent être identiques';
b_mp=false;
}
else
{
document.getElementById('message').innerText = '';
document.getElementById(nom_controle).style.border = '#333 1px solid';
b_mp=true;
}
}else if(nom_controle=='tel')
{
  var long = document.getElementById(nom_controle).value.length;
   if(long<8)document.getElementById('message').innerText='impossible de voir un numéro de téléphone inférieur à 8';
  else {
    b_tel=true;
    document.getElementById('message').innerText='';
}}





  
  else if(longueur<4 || document.getElementById(nom_controle).value == txt_defaut)
  {
  document.getElementById(nom_controle).style.border='#CC3300 2px solid';
  document.getElementById('message').innerText='votre chain de taille très petite';
  
  switch(nom_controle)
  {
  case 'nom':
  b_nom=false;
  break;
  case 'prenom':
  b_prenom=false;
  break;
  case 'tel':
  b_tel = false;
  break;
  case 'mail_inscr':
  b_mail=false;
  break;
  case 'mp_inscr':
  b_mp=false;
  break;
  }
  }
  else
  {
  document.getElementById(nom_controle).style.border='#333 1px solid';
  
  switch(nom_controle)
  {
  case 'nom':
  b_nom=true;
  break;
  case 'prenom':
  b_prenom=true;
  break;
  case 'tel' :
    b_tel=true;
    
  }
  }
  
}